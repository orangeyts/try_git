package org;

import java.io.File;
import java.io.FileOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Expand;

import com.github.junrar.Archive;
import com.github.junrar.rarfile.FileHeader;

public class UnCompress {
	/**
	    * 解压缩文件可以兼容 rar和zip以及中文文件item
	    * @param compresFile		压缩文件
	    * @param unCompresDestDir	解压目录
	    * @throws Exception 
	    */
	   public static void unCompressPackage(String compresFile, String unCompresDestDir) throws Exception
	   {
		   String compresssufix = compresFile.substring(compresFile.lastIndexOf(".")+1);
		   
		   File compresFileObj = new File(compresFile);
		   if (compresssufix.equalsIgnoreCase("zip")) {
			   if (!compresFileObj.exists())  
				    throw new RuntimeException("zip file " + compresFile  
				        + " does not exist.");  
				  
		        Project proj = new Project();  
		        Expand expand = new Expand();  
		        expand.setProject(proj);  
		        expand.setTaskType("unzip");  
				expand.setTaskName("unzip");  
				expand.setEncoding("gbk");  
				  
		        expand.setSrc(new File(compresFile));  
		        expand.setDest(new File(unCompresDestDir));  
		        expand.execute();  
		   }else if (compresssufix.equalsIgnoreCase("rar")) {
			   Archive a = null;  
		       FileOutputStream fos = null;  
		       try{  
		           a = new Archive(new File(compresFile));
//				a.setVolumeManager(new VolumeManager(){
//
//					public Volume nextArchive(Archive arg0, Volume arg1)
//							throws IOException {
//						// TODO Auto-generated method stub
//						return null;
//					}
//					
//				});
		           FileHeader fh = a.nextFileHeader();
		           while(fh!=null){  
		               if(!fh.isDirectory()){  
		                   //1 根据不同的操作系统拿到相应的 destDirName 和 destFileName  
		                   //String compressFileName = fh.getFileNameString().trim();
		                   String compressFileName= fh.getFileNameW().trim();
		                   if(!existZH(compressFileName)){
		                	   compressFileName = fh.getFileNameString().trim();
		                   }
		                   
		                   System.out.println("rar item name: "+compressFileName);
		                   String destFileName = "";  
		                   String destDirName = "";  
		                   //非windows系统  
		                   if(File.separator.equals("/")){  
		                       destFileName = unCompresDestDir + File.separator + compressFileName.replaceAll("\\\\", "/");  
		                       destDirName = destFileName.substring(0, destFileName.lastIndexOf("/"));  
		                   //windows系统   
		                   }else{  
		                       destFileName = unCompresDestDir + File.separator + compressFileName.replaceAll("/", "\\\\");  
		                       destDirName = destFileName.substring(0, destFileName.lastIndexOf("\\"));  
		                   }  
		                   //2创建文件夹  
		                   File dir = new File(destDirName);  
		                   if(!dir.exists()||!dir.isDirectory()){  
		                       dir.mkdirs();  
		                   }  
		                   System.out.println("un rar file :"+destFileName);
		                   //3解压缩文件  
		                   fos = new FileOutputStream(new File(destFileName));  
		                   a.extractFile(fh, fos);  
		                   fos.close();  
		                   fos = null;  
		               }  
		               fh = a.nextFileHeader();  
		           }  
		           a.close();  
		           a = null;  
		       }catch(Exception e){  
		           throw e;  
		       }finally{  
		           if(fos!=null){  
		               try{fos.close();fos=null;}catch(Exception e){e.printStackTrace();}  
		           }  
		           if(a!=null){  
		               try{a.close();a=null;}catch(Exception e){e.printStackTrace();}  
		           }  
		       }   
		   }
			
	   }
	   
	   public static boolean existZH(String str) {
		   String regEx = "[\\u4e00-\\u9fa5]";
		   Pattern p = Pattern.compile(regEx);
		   Matcher m = p.matcher(str);
		   while (m.find()) {
			   return true;
		   }
		   return false;
	  }
	   
	   public static void main(String[] args) throws Exception {
		String prefix = "D:/***/project/app/workspace/UnCompress/";
		String compresFile = prefix + File.separator + "resource/uncompress/rur-ple-1.0.1zip.zip";
		String unCompresDestDir = prefix + File.separator + "target";
		unCompressPackage(compresFile, unCompresDestDir);
	}
}
